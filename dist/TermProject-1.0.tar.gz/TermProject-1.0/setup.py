from distutils.core import setup, Extension

setup(name= 'TermProject',
      version='1.0',
      py_modules=['TermProject'],
      packages=['TermProject'],
      )